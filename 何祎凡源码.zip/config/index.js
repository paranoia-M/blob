import menus from './menus'

export default {
  menus
}

import Login from '@/views/login/index.vue'

const routes = [
  {
    path: '/',
    name: 'login',
    component: Login
  }
]

export default routes

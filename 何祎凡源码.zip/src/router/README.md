- 格式说明
```js
let demo = {
  redirect: noredirect,
  name: 'router-name',
  hidden: true,
  code: 1,
  meta: {
    title: 'title',
    icon: 'a-icon',
    target: '_blank|_self|_top|_parent',
    keepAlive: true,
    hiddenHeaderContent: true,
  }
}
```

<template>
  <div>
    <keep-alive>
      <router-view/>
    </keep-alive>
  </div>
</template>

<script>
export default {
  name: 'blank',
  data () {
    return {}
  },
  methods: {}
}
</script>

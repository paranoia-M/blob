<template>
  <footer>
    <p></p>
  </footer>
</template>

<script>
export default {
  name: 'index',
  data () {
    return {}
  },
  methods: {}
}
</script>

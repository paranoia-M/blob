<template>
  <div>
    <iframe src="https://jakhuang.github.io/form-generator/#/" height="600" frameborder="0" scrolling="auto" style="width: 100%"></iframe>
  </div>
</template>

<script>
export default {
  name: 'index',
  data () {
    return {}
  },
  methods: {}
}
</script>

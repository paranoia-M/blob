<template>
  <div>
    <h2>鼠标拖动任务</h2>
    <Task></Task>
  </div>

</template>

<script>

import Task from '@/components/Task'

export default {
  name: 'index',
  components: {
    Task
  },
  data () {
    return {}
  },
  methods: {}
}
</script>
